#define UTS_RELEASE "4.8.0-54-generic"
#define UTS_UBUNTU_RELEASE_ABI 54
